import pygame
import os
import random
import sys
import math

def carregar_imagem(nome, escala=None):
    caminho = os.path.join("imagens", nome)
    try:
        img = pygame.image.load(caminho).convert_alpha()
        return pygame.transform.scale(img, escala) if escala else img
    except:
        print(f"Erro ao carregar imagem: {nome}")
        superficie = pygame.Surface((100, 100), pygame.SRCALPHA)
        superficie.fill((255, 0, 0, 128))
        return superficie

class Jogo:
    def __init__(self, volume_inicial=0.5):  # Adicione valor padrão
        pygame.init()
        self.WIDTH, self.HEIGHT = 960, 720
        self.screen = pygame.display.set_mode((self.WIDTH, self.HEIGHT))
        pygame.display.set_caption("All In - Fase com Agiota")
        
        self.volume = volume_inicial  # Armazena o volume atual
        
        # Configuração de cores
        self.CORES = {
            "FUNDO": (20, 20, 40),
            "TEXTO": (240, 240, 240),
            "DESTAQUE": (255, 215, 0),  # Dourado
            "ERRO": (255, 80, 80),
            "SUCESSO": (80, 220, 80),
            "INFO": (100, 180, 255)
        }

        # Configuração de fontes
        try:
            self.fonte_pequena = pygame.font.Font(None, 24)
            self.fonte_normal = pygame.font.Font(None, 32)
            self.fonte_grande = pygame.font.Font(None, 48)
            self.fonte_titulo = pygame.font.Font(None, 64)
        except:
            self.fonte_pequena = pygame.font.SysFont("arial", 24)
            self.fonte_normal = pygame.font.SysFont("arial", 32)
            self.fonte_grande = pygame.font.SysFont("arial", 48)
            self.fonte_titulo = pygame.font.SysFont("arial", 64)

        self.clock = pygame.time.Clock()
        self.carregar_assets()
        self.resetar_jogo()

        pygame.mixer.music.load("imagens/musica_cassino.wav")
        pygame.mixer.music.set_volume(self.volume)
        pygame.mixer.music.play(-1)
        
    def resetar_jogo(self):
        """Reseta todas as variáveis do jogo"""
        self.pausado = False
        self.mostrar_instrucoes = True
        self.fase = 1
        self.dinheiro = 200
        self.pontuacao = 0
        self.velocidade_jogador = 4
        self.objetivo_dinheiro = 200
        self.game_over_visible = False
        self.transicao_ativa = False
        self.ranking = self.carregar_ranking()

    def carregar_assets(self):
        """Carrega todas as imagens"""
        self.gabriel_img = carregar_imagem("gabriel.png", (50, 50))
        self.caca_niquel_img = carregar_imagem("caca_niquel.png", (70, 70))
        self.nota_img = carregar_imagem("nota_dinheiro.png", (25, 25))
        self.saco_img = carregar_imagem("moeda_saco.png", (25, 25))
        self.agiota_img = carregar_imagem("agiota.png", (40, 40))
        self.tela_game_over = carregar_imagem("tela_game_over.jpg", (self.WIDTH, self.HEIGHT))
        
        # Carrega os obstáculos das máquinas
        self.obstaculo_maquina = carregar_imagem("obstaculo_maquina.png")
        self.obstaculo_maquina_dupla = carregar_imagem("obstaculo_maquina_dupla.png")
        self.obstaculo_maquina_tripla = carregar_imagem("obstaculo_maquina_tripla.png")
        
        # Carrega o som de game over
        self.game_over_sound = pygame.mixer.Sound("imagens/game_over.mp3")

    def carregar_ranking(self):
        """Carrega o ranking do arquivo ou cria um novo se não existir"""
        try:
            with open("ranking.txt", "r") as f:
                linhas = f.readlines()
                ranking = []
                for linha in linhas:
                    nome, pontos = linha.strip().split(",")
                    ranking.append((nome, int(pontos)))
                # Ordena por pontuação (decrescente)
                ranking.sort(key=lambda x: x[1], reverse=True)
                return ranking[:5]  # Mantém apenas os top 5
        except:
            return []

    def salvar_ranking(self):
        """Salva o ranking no arquivo"""
        with open("ranking.txt", "w") as f:
            for nome, pontos in self.ranking:
                f.write(f"{nome},{pontos}\n")

    def adicionar_pontuacao(self, nome, pontos):
        """Adiciona uma nova pontuação ao ranking"""
        self.ranking.append((nome, pontos))
        self.ranking.sort(key=lambda x: x[1], reverse=True)
        self.ranking = self.ranking[:5]  # Mantém apenas os top 5
        self.salvar_ranking()

    def criar_obstaculo(self, x, y, tipo, orientacao="horizontal"):
        """Cria um obstáculo com as imagens das máquinas"""
        if tipo == "pequeno":
            img = self.obstaculo_maquina
            hitbox = pygame.Rect(0, 0, 60, 60)  # Hitbox menor que a imagem
        elif tipo == "medio":
            img = self.obstaculo_maquina_dupla
            hitbox = pygame.Rect(0, 0, 120, 60)  # Hitbox menor que a imagem
        else:  # grande
            img = self.obstaculo_maquina_tripla
            hitbox = pygame.Rect(0, 0, 180, 60)  # Hitbox menor que a imagem
        
        if orientacao == "vertical":
            img = pygame.transform.rotate(img, 90)
            hitbox.width, hitbox.height = hitbox.height, hitbox.width  # Inverte para vertical
        
        rect = img.get_rect(topleft=(x, y))
        hitbox.center = rect.center  # Centraliza a hitbox na imagem
        
        return {"img": img, "rect": rect, "hitbox": hitbox, "tipo": tipo, "orientacao": orientacao}

    def layout_fase1(self):
        """Fase 1 com obstáculos básicos"""
        obstaculos = []
        obstaculos.append(self.criar_obstaculo(200, 200, "pequeno"))
        obstaculos.append(self.criar_obstaculo(500, 200, "medio"))
        obstaculos.append(self.criar_obstaculo(200, 500, "grande"))
        obstaculos.append(self.criar_obstaculo(500, 500, "pequeno"))
        obstaculos.append(self.criar_obstaculo(350, 300, "pequeno", "vertical"))
        return obstaculos

    def layout_fase2(self):
        """Fase 2 com padrão de labirinto mais fluido"""
        obstaculos = []
        # Padrão mais aberto com corredores mais largos
        obstaculos.append(self.criar_obstaculo(150, 150, "grande"))
        obstaculos.append(self.criar_obstaculo(550, 150, "medio"))
        obstaculos.append(self.criar_obstaculo(150, 450, "grande"))
        obstaculos.append(self.criar_obstaculo(550, 450, "medio"))
        
        # Obstáculos verticais mais espaçados
        obstaculos.append(self.criar_obstaculo(300, 200, "pequeno", "vertical"))
        obstaculos.append(self.criar_obstaculo(450, 300, "pequeno", "vertical"))
        return obstaculos

    def layout_fase3(self):
        """Fase 3 com padrão mais complexo mas fluido"""
        obstaculos = []
        # Ajustado para ter corredores mais largos
        obstaculos.append(self.criar_obstaculo(100, 100, "grande"))
        obstaculos.append(self.criar_obstaculo(500, 100, "grande"))
        obstaculos.append(self.criar_obstaculo(100, 600, "grande"))
        obstaculos.append(self.criar_obstaculo(500, 600, "grande"))
        
        # Obstáculos verticais com mais espaço entre eles
        obstaculos.append(self.criar_obstaculo(300, 150, "medio", "vertical"))
        obstaculos.append(self.criar_obstaculo(600, 150, "medio", "vertical"))
        obstaculos.append(self.criar_obstaculo(200, 400, "pequeno", "vertical"))
        obstaculos.append(self.criar_obstaculo(700, 400, "pequeno", "vertical"))
        return obstaculos

    def layout_fase4(self):
        """Fase 4 com obstáculos em cruz mas mais fluida"""
        obstaculos = []
        # Padrão de cruz mais aberto
        for i in range(3):
            y = 150 + i * 200
            obstaculos.append(self.criar_obstaculo(150, y, "grande"))
            obstaculos.append(self.criar_obstaculo(550, y, "grande"))
        
        for i in range(2):
            x = 300 + i * 200
            obstaculos.append(self.criar_obstaculo(x, 200, "medio", "vertical"))
            obstaculos.append(self.criar_obstaculo(x, 500, "medio", "vertical"))
        
        # Obstáculos centrais mais espaçados
        obstaculos.append(self.criar_obstaculo(400, 350, "pequeno"))
        obstaculos.append(self.criar_obstaculo(470, 250, "pequeno", "vertical"))
        return obstaculos

    def mostrar_texto(self, texto, tamanho="normal", cor="TEXTO", posicao=None, centralizado=False):
        """Exibe texto na tela com estilo consistente"""
        if tamanho == "pequeno":
            fonte = self.fonte_pequena
        elif tamanho == "grande":
            fonte = self.fonte_grande
        elif tamanho == "titulo":
            fonte = self.fonte_titulo
        else:
            fonte = self.fonte_normal
        
        texto_surf = fonte.render(texto, True, self.CORES[cor])
        
        if posicao is None:
            posicao = (20, 20)
        
        if centralizado:
            posicao = (self.WIDTH//2 - texto_surf.get_width()//2, posicao[1])
        
        self.screen.blit(texto_surf, posicao)

    def mostrar_tela_salvar_pontuacao(self):
        """Tela para digitar 3 letras e salvar pontuação"""
        nome = ""
        while True:
            self.screen.fill(self.CORES["FUNDO"])
            self.mostrar_texto("GAME OVER", "titulo", "ERRO", (self.WIDTH//2, 100), True)
            self.mostrar_texto(f"Pontuação: {self.pontuacao}", "grande", "TEXTO", (self.WIDTH//2, 200), True)
            self.mostrar_texto("Digite 3 letras para salvar:", "normal", "TEXTO", (self.WIDTH//2, 300), True)
            
            # Mostra o nome sendo digitado
            nome_surf = self.fonte_grande.render(nome, True, self.CORES["DESTAQUE"])
            self.screen.blit(nome_surf, (self.WIDTH//2 - nome_surf.get_width()//2, 350))
            
            pygame.display.flip()
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN and len(nome) == 3:
                        self.adicionar_pontuacao(nome, self.pontuacao)
                        return
                    elif event.key == pygame.K_BACKSPACE:
                        nome = nome[:-1]
                    elif event.unicode.isalpha() and len(nome) < 3:
                        nome += event.unicode.upper()

    def mostrar_tela_ranking(self):
        """Mostra o ranking dos melhores jogadores"""
        self.screen.fill(self.CORES["FUNDO"])
        self.mostrar_texto("TOP 5 MELHORES PONTUAÇÕES", "titulo", "DESTAQUE", (self.WIDTH//2, 100), True)
        
        if not self.ranking:
            self.mostrar_texto("Nenhuma pontuação registrada ainda", "normal", "TEXTO", (self.WIDTH//2, 300), True)
        else:
            for i, (nome, pontos) in enumerate(self.ranking):
                texto = f"{i+1}. {nome} - {pontos} pontos"
                self.mostrar_texto(texto, "grande", "TEXTO", (self.WIDTH//2, 200 + i * 60), True)
        
        self.mostrar_texto("Pressione qualquer tecla para continuar", "normal", "TEXTO", (self.WIDTH//2, self.HEIGHT - 100), True)
        pygame.display.flip()
        
        esperando = True
        while esperando:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    esperando = False

    def mostrar_tela_final_game_over(self):
        """Tela final de game over com opções ajustadas"""
        self.screen.blit(self.tela_game_over, (0, 0))
    
        # Configurações de fonte
        fonte = self.fonte_normal  # Usa a fonte normal para tudo
        cor_texto = self.CORES["TEXTO"]
        cor_destaque = self.CORES["ERRO"]  # Vermelho para a frase do agiota
    
        # Calcula posições relativas
        y_base = self.HEIGHT // 2 + 100  # Começa mais abaixo na tela
    
        # Frase do agiota em vermelho
        texto_agiota = fonte.render("O agiota sempre ficará com o dinheiro", True, cor_destaque)
        self.screen.blit(texto_agiota, (self.WIDTH//2 - texto_agiota.get_width()//2, y_base))
    
        # Pontuação
        texto_pontuacao = fonte.render(f"Pontuação: {self.pontuacao}", True, cor_texto)
        self.screen.blit(texto_pontuacao, (self.WIDTH//2 - texto_pontuacao.get_width()//2, y_base + 50))
    
        # Instruções (todas com mesma fonte e tamanho)
        texto_reiniciar = fonte.render("Pressione R para reiniciar", True, cor_texto)
        self.screen.blit(texto_reiniciar, (self.WIDTH//2 - texto_reiniciar.get_width()//2, y_base + 100))
    
        texto_menu = fonte.render("ou ESC para voltar ao menu", True, cor_texto)
        self.screen.blit(texto_menu, (self.WIDTH//2 - texto_menu.get_width()//2, y_base + 150))
    
        pygame.display.flip()
    
        esperando = True
        while esperando:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        self.game_over_sound.stop()
                        return "reiniciar"
                    elif event.key == pygame.K_ESCAPE:
                        self.game_over_sound.stop()
                        return "menu"

    def mostrar_tela_game_over(self):
        """Fluxo completo do game over"""
        pygame.mixer.music.stop()
        self.game_over_sound.play()
    
        # 1. Tela para salvar pontuação
        self.mostrar_tela_salvar_pontuacao()
    
        # 2. Mostra o ranking
        self.mostrar_tela_ranking()
    
        # 3. Tela final com opções
        resultado = self.mostrar_tela_final_game_over()
    
        return resultado

    def mostrar_tela_vitoria(self):
        """Exibe a tela de vitória e permite salvar a pontuação"""
        nome = ""
        digitando = True
        salvo = False
        
        while digitando:
            self.screen.fill(self.CORES["FUNDO"])
            self.mostrar_texto("Parabéns! Você completou todas as fases!", "grande", "SUCESSO", 
                             (self.WIDTH//2, self.HEIGHT//2 - 100), True)
            self.mostrar_texto(f"Pontuação final: {self.pontuacao}", "normal", "TEXTO", 
                             (self.WIDTH//2, self.HEIGHT//2 - 40), True)
            
            if not salvo:
                self.mostrar_texto("Digite 3 letras para salvar sua pontuação:", "normal", "TEXTO",
                                 (self.WIDTH//2, self.HEIGHT//2 + 20), True)
                
                # Mostra o nome sendo digitado
                nome_surf = self.fonte_grande.render(nome, True, self.CORES["DESTAQUE"])
                self.screen.blit(nome_surf, (self.WIDTH//2 - nome_surf.get_width()//2, self.HEIGHT//2 + 60))
                
                pygame.display.flip()
                
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_RETURN and len(nome) == 3:
                            self.adicionar_pontuacao(nome, self.pontuacao)
                            salvo = True
                        elif event.key == pygame.K_BACKSPACE:
                            nome = nome[:-1]
                        elif event.unicode.isalpha() and len(nome) < 3:
                            nome += event.unicode.upper()
            else:
                self.mostrar_texto("Pontuação salva com sucesso!", "normal", "SUCESSO",
                                  (self.WIDTH//2, self.HEIGHT//2 + 20), True)
                self.mostrar_texto("Pressione qualquer tecla para ver o ranking", "normal", "TEXTO",
                                  (self.WIDTH//2, self.HEIGHT//2 + 60), True)
                pygame.display.flip()
                
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    elif event.type == pygame.KEYDOWN:
                        digitando = False
        
        # Mostra o ranking
        self.mostrar_tela_ranking()
        return "menu"

    def mostrar_ranking(self):
        """Exibe a tela de ranking"""
        self.screen.fill(self.CORES["FUNDO"])
        self.mostrar_texto("TOP 5 MELHORES PONTUAÇÕES", "titulo", "DESTAQUE", 
                          (self.WIDTH//2, 100), True)
        
        if not self.ranking:
            self.mostrar_texto("Nenhuma pontuação registrada ainda", "normal", "TEXTO",
                             (self.WIDTH//2, self.HEIGHT//2), True)
        else:
            for i, (nome, pontos) in enumerate(self.ranking):
                texto = f"{i+1}. {nome} - {pontos} pontos"
                self.mostrar_texto(texto, "grande", "TEXTO", 
                                  (self.WIDTH//2, 200 + i * 60), True)
        
        self.mostrar_texto("Pressione qualquer tecla para voltar ao menu", "normal", "TEXTO",
                          (self.WIDTH//2, self.HEIGHT - 60), True)
        pygame.display.flip()
        
        esperando = True
        while esperando:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    esperando = False

    def iniciar_fase(self):
        """Prepara uma nova fase"""
        layouts = {
            1: self.layout_fase1,
            2: self.layout_fase2,
            3: self.layout_fase3,
            4: self.layout_fase4
        }
    
        self.obstaculos = layouts.get(self.fase, self.layout_fase4)()
    
        # Posição inicial do jogador - ajustada para cada fase
        if self.fase == 1:
            self.gabriel_rect = self.gabriel_img.get_rect(topleft=(80, 80))
        elif self.fase == 2:
            self.gabriel_rect = self.gabriel_img.get_rect(topleft=(100, 100))
        elif self.fase == 3:
            self.gabriel_rect = self.gabriel_img.get_rect(topleft=(100, 350))
        else:  # fase 4
            self.gabriel_rect = self.gabriel_img.get_rect(topleft=(100, 350))
        
        self.caca_niquel_rect = self.caca_niquel_img.get_rect(center=(self.WIDTH-80, self.HEIGHT-80))
        self.agiota_rect = self.agiota_img.get_rect(topleft=(self.WIDTH-120, 80))
        self.movimento_iniciado = False
    
        # Gera coletáveis em posições válidas 
        self.coletaveis = []
        if self.fase > 1:  # Fase 1 não terá coletáveis
            for _ in range(10 + self.fase * 5):  # Quantidade dos coletáveis
                while True:
                    x = random.randint(80, self.WIDTH - 100)
                    y = random.randint(80, self.HEIGHT - 100)
                    item_rect = pygame.Rect(x, y, 25, 25)
                
                    # Verifica se não colide com obstáculos ou outros itens
                    colisao = any(item_rect.colliderect(o["hitbox"]) for o in self.obstaculos)
                    if not colisao and not any(item_rect.colliderect(c["rect"]) for c in self.coletaveis):
                        valor = random.choice([20, 50])
                        tipo = "nota" if valor == 50 else "saco"
                        img = self.nota_img if tipo == "nota" else self.saco_img
                        self.coletaveis.append({
                            "valor": valor,
                            "rect": img.get_rect(topleft=(x, y)),
                            "img": img
                        })
                        break

    def mover_agiota_suave(self):
        """Movimento do agiota"""
        jogador_pos = pygame.Vector2(self.gabriel_rect.center)
        agiota_pos = pygame.Vector2(self.agiota_rect.center)
    
        direcao = jogador_pos - agiota_pos
        if direcao.length() == 0:
            return self.agiota_rect
    
        distancia = direcao.length()
        direcao = direcao.normalize()
    
        # Ajuste de velocidade por fase
        if self.fase == 4:  # Fase 4 - agiota extremamente rápido
            velocidade = 7
        elif self.fase == 2:
            velocidade = min(2.5, 3)  
        else:
            velocidade = min(3 + (self.fase-1) * 0.5, 5)
    
        nova_pos = self.agiota_rect.copy()
        nova_pos.x += direcao.x * velocidade
        nova_pos.y += direcao.y * velocidade
    
        if not any(nova_pos.colliderect(o["hitbox"]) for o in self.obstaculos):
            self.agiota_rect = nova_pos
            return self.agiota_rect
    
        for angulo in [45, -45, 90, -90, 135, -135]:
            angulo_rad = math.radians(angulo)
            nova_direcao = pygame.Vector2(
                direcao.x * math.cos(angulo_rad) - direcao.y * math.sin(angulo_rad),
                direcao.x * math.sin(angulo_rad) + direcao.y * math.cos(angulo_rad)
            ).normalize()
        
            nova_pos = self.agiota_rect.copy()
            nova_pos.x += nova_direcao.x * velocidade * 0.7
            nova_pos.y += nova_direcao.y * velocidade * 0.7
        
            if not any(nova_pos.colliderect(o["hitbox"]) for o in self.obstaculos):
                self.agiota_rect = nova_pos
                return self.agiota_rect
    
        if abs(direcao.x) > abs(direcao.y):
            nova_pos = self.agiota_rect.copy()
            nova_pos.x += direcao.x * velocidade
            if not any(nova_pos.colliderect(o["hitbox"]) for o in self.obstaculos):
                self.agiota_rect.x = nova_pos.x
            else:
                nova_pos = self.agiota_rect.copy()
                nova_pos.y += direcao.y * velocidade
                if not any(nova_pos.colliderect(o["hitbox"]) for o in self.obstaculos):
                    self.agiota_rect.y = nova_pos.y
        else:
            nova_pos = self.agiota_rect.copy()
            nova_pos.y += direcao.y * velocidade
            if not any(nova_pos.colliderect(o["hitbox"]) for o in self.obstaculos):
                self.agiota_rect.y = nova_pos.y
            else:
                nova_pos = self.agiota_rect.copy()
                nova_pos.x += direcao.x * velocidade
                if not any(nova_pos.colliderect(o["hitbox"]) for o in self.obstaculos):
                    self.agiota_rect.x = nova_pos.x
    
        return self.agiota_rect

    def rodar_jogo(self):
        """Loop principal do jogo"""
        self.iniciar_fase()
        
        if self.mostrar_instrucoes:
            self.screen.fill(self.CORES["FUNDO"])
            self.mostrar_texto("All In - Caça-Níquel", "titulo", "DESTAQUE", (self.WIDTH//2, self.HEIGHT//2 - 100), True)
            self.mostrar_texto("Colete R$200 para jogar no caça-níquel", "normal", "TEXTO", (self.WIDTH//2, self.HEIGHT//2 - 20), True)
            self.mostrar_texto("Use as setas para se movimentar", "normal", "TEXTO", (self.WIDTH//2, self.HEIGHT//2 + 20), True)
            self.mostrar_texto("Pressione qualquer tecla para começar", "normal", "DESTAQUE", (self.WIDTH//2, self.HEIGHT//2 + 80), True)
            pygame.display.flip()
            
            esperando = True
            while esperando:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.KEYDOWN:
                        esperando = False
            
            self.mostrar_instrucoes = False

        rodando = True
        while rodando:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return "sair"
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.pausado = not self.pausado
                        if self.pausado:
                            self.screen.fill(self.CORES["FUNDO"])
                            self.mostrar_texto("Jogo Pausado", "grande", "DESTAQUE", (self.WIDTH//2, self.HEIGHT//2 - 30), True)
                            self.mostrar_texto("Pressione ESC para continuar", "normal", "TEXTO", (self.WIDTH//2, self.HEIGHT//2 + 30), True)
                            pygame.display.flip()

            if self.pausado:
                continue

            # Movimento do jogador
            teclas = pygame.key.get_pressed()
            movimento = [0, 0]
            if teclas[pygame.K_LEFT]: movimento[0] -= self.velocidade_jogador
            if teclas[pygame.K_RIGHT]: movimento[0] += self.velocidade_jogador
            if teclas[pygame.K_UP]: movimento[1] -= self.velocidade_jogador
            if teclas[pygame.K_DOWN]: movimento[1] += self.velocidade_jogador

            if any(movimento):
                self.movimento_iniciado = True

            # Atualiza posição do jogador
            novo_rect = self.gabriel_rect.move(movimento)
            if (0 <= novo_rect.left and novo_rect.right <= self.WIDTH and
                0 <= novo_rect.top and novo_rect.bottom <= self.HEIGHT):
                colidiu = any(novo_rect.colliderect(o["hitbox"]) for o in self.obstaculos)
                if not colidiu:
                    self.gabriel_rect = novo_rect

            # Verifica coleta de itens (apenas se existirem coletáveis)
            if hasattr(self, 'coletaveis'):
                for item in self.coletaveis[:]:
                    if self.gabriel_rect.colliderect(item["rect"]):
                        self.dinheiro += item["valor"]
                        self.pontuacao += item["valor"]
                        self.coletaveis.remove(item)

            # Movimento do agiota (fases 2+)
            if self.fase >= 2 and self.movimento_iniciado:
                self.agiota_rect = self.mover_agiota_suave()

            # Verifica colisão com agiota
            if self.fase >= 2 and self.gabriel_rect.colliderect(self.agiota_rect):
                return "game_over"

            # Renderização
            self.screen.fill(self.CORES["FUNDO"])
            
            # Desenha obstáculos
            for obstaculo in self.obstaculos:
                self.screen.blit(obstaculo["img"], obstaculo["rect"])
            
            # Desenha coletáveis (se existirem)
            if hasattr(self, 'coletaveis'):
                for item in self.coletaveis:
                    self.screen.blit(item["img"], item["rect"])
            
            # Desenha personagens
            self.screen.blit(self.gabriel_img, self.gabriel_rect)
            self.screen.blit(self.caca_niquel_img, self.caca_niquel_rect)
            if self.fase >= 2:
                self.screen.blit(self.agiota_img, self.agiota_rect)

            # UI - Informações do jogo
            self.mostrar_texto(f"Fase: {self.fase}", "pequeno", "DESTAQUE", (20, 20))
            self.mostrar_texto(f"Pontuação: {self.pontuacao}", "pequeno", "TEXTO", (self.WIDTH - 200, 20))
            self.mostrar_texto(f"Dinheiro: R${self.dinheiro}", "pequeno", "SUCESSO", (self.WIDTH - 200, 50))
            self.mostrar_texto(f"Objetivo: R${self.objetivo_dinheiro}", "pequeno", "DESTAQUE", (20, 50))

            # Verifica se chegou no caça-níquel
            if self.gabriel_rect.colliderect(self.caca_niquel_rect):
                if self.dinheiro >= self.objetivo_dinheiro:
                    self.dinheiro -= 200  # Subtrai 200 do dinheiro acumulado
                    self.screen.fill(self.CORES["FUNDO"])
                    self.mostrar_texto("Você apostou 200 R$ e perdeu!", "grande", "ERRO", (self.WIDTH//2, self.HEIGHT//2 - 80), True)
                    self.mostrar_texto("Recupere e jogue novamente!", "normal", "TEXTO", (self.WIDTH//2, self.HEIGHT//2 - 30), True)
                    self.mostrar_texto(f"Indo para fase {self.fase+1}...", "normal", "TEXTO", (self.WIDTH//2, self.HEIGHT//2 + 20), True)
                    pygame.display.flip()
                    pygame.time.delay(3000)  # Aumentei o delay para dar tempo de ler
                    
                    self.fase += 1
                    if self.fase > 4:
                        return "vitoria"
                    return "proxima_fase"
                else:
                    self.mostrar_texto("Você precisa de R$200 para jogar!", "pequeno", "ERRO", (self.WIDTH//2, self.HEIGHT - 40), True)

            pygame.display.flip()
            self.clock.tick(60)

    def iniciar(self):
        """Loop principal do programa"""
        while True:
            resultado = self.rodar_jogo()
        
            if resultado == "game_over":
                acao = self.mostrar_tela_game_over()
                if acao == "menu":
                    pygame.mixer.music.stop()
                    return "menu"  # Retorna explicitamente para o menu
                elif acao == "reiniciar":
                    self.resetar_jogo()
                    continue
                
            elif resultado == "vitoria":
                acao = self.mostrar_tela_vitoria()
                if acao == "menu":
                    return "menu"
                
            elif resultado == "sair":
                pygame.quit()
                sys.exit()

def iniciar_jogo(volume_inicial=0.5):  # Adiciona valor padrão
    jogo = Jogo(volume_inicial)
    return jogo.iniciar() # Retorna o resultado

if __name__ == "__main__":
    jogo = Jogo()
    jogo.iniciar()