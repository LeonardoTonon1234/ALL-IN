import pygame
import sys
import os
from jogo import iniciar_jogo  

pygame.init()
pygame.mixer.init()

# Configurações da tela
screen_width = 960
screen_height = 720
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("All In")

# Cores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
DARK_BOX = (20, 20, 20)
BUTTON_COLOR = (200, 50, 50)
BUTTON_HOVER = (255, 100, 100)
GOLD = (212, 175, 55)

# Fontes
font = pygame.font.SysFont("arial", 28)
context_font = pygame.font.SysFont("arial", 24, italic=True)
title_font = pygame.font.SysFont("arial", 60, bold=True)
small_font = pygame.font.SysFont("arial", 20)

# Música
pygame.mixer.music.load("imagens/musica_cassino.wav")
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(-1)

# Botão
class Button:
    def __init__(self, x, y, w, h, text):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.hovered = False

    def draw(self, surface):
        color = BUTTON_HOVER if self.hovered else BUTTON_COLOR
        pygame.draw.rect(surface, color, self.rect, border_radius=10)
        pygame.draw.rect(surface, WHITE, self.rect, 2, border_radius=10)
        text_surf = font.render(self.text, True, WHITE)
        surface.blit(text_surf, (self.rect.centerx - text_surf.get_width() // 2,
                                 self.rect.centery - text_surf.get_height() // 2))

    def update(self, pos):
        self.hovered = self.rect.collidepoint(pos)

    def clicked(self, pos):
        return self.rect.collidepoint(pos)

# Imagens
def carregar_imagem(nome):
    caminho = os.path.join("imagens", nome)
    return pygame.transform.scale(pygame.image.load(caminho), (screen_width, screen_height))

imagens = [
    carregar_imagem("tela_inicial.jpg"),
    carregar_imagem("gabriel_computador.jpg"),
    carregar_imagem("gabriel_encontra_eduardo.jpg"),
    carregar_imagem("gabriel_pensativo.jpg"),
    carregar_imagem("gabriel_encontra_bob.jpg"),
    carregar_imagem("gabriel_dinheiro.jpg"),
    carregar_imagem("gabriel_entrando_no_cassino.jpg")
]

# Cenas
cenas = [
    {"imagem": imagens[1], "contexto": "Gabriel, depois de um dia cansativo, chega em casa e abre seu computador.",
     "falas": ["Ganhe dinheiro jogando!", "Transforme seu tempo livre em dinheiro fácil!", "Faça sua própria sorte agora!"]},
    {"imagem": imagens[2], "contexto": "Gabriel encontra um velho amigo...",
     "falas": ["E aí, Gabriel? Quanto tempo, mano!", "Você está sabendo do novo cassino aqui perto?",
               "Tem o melhor caça-níquel de São Paulo, está dando muito dinheiro.",
               "Preciso conseguir o suficiente pra sacar, por causa do limite mínimo."]},
    {"imagem": imagens[3], "contexto": "Gabriel no caminho de volta para casa...",
     "falas": ["Será que tudo isso é verdade?", "Talvez eu consiga mudar de vida, ganhar muito dinheiro finalmente."]},
    {"imagem": imagens[4], "contexto": "Passando pela rua no seu dia de trabalho, Gabriel é abordado...",
     "falas": ["E aí garoto, já conheceu o novo caça-níquel que todo mundo anda falando?",
               "Tenho certeza que você tá querendo jogar.",
               "Vou te emprestar um dinheiro pra te ajudar na sua correria."]},
    {"imagem": imagens[5], "contexto": "Gabriel em casa, pensando com o dinheiro nas mãos...",
     "falas": ["Amanhã eu estou pronto pra jogar.", "Vamos ver se isso realmente vai me ajudar."]},
    {"imagem": imagens[6], "contexto": "No dia seguinte...", "falas": ["Já estou aqui, é agora ou nunca."]}
]

# Estados
inicio = True
narrativa = False
creditos = False
configuracoes = False
indice_cena = 0
indice_fala = 0
texto_parcial = ""
tempo_fala = 0
velocidade_texto = 30
volume = 0.5  # Volume inicial

# Botões
botao_jogar = Button(screen_width // 2 - 150, 400, 300, 60, "Iniciar Jogo")
botao_config = Button(screen_width // 2 - 150, 480, 300, 60, "Configurações")
botao_creditos = Button(screen_width // 2 - 150, 560, 300, 60, "Créditos")
botao_sair = Button(screen_width // 2 - 150, 640, 300, 60, "Sair")

# Botões de configuração
botao_voltar = Button(screen_width // 2 - 150, 600, 300, 60, "Voltar")
botao_volume_mais = Button(screen_width // 2 + 100, 400, 50, 50, "+")
botao_volume_menos = Button(screen_width // 2 - 150, 400, 50, 50, "-")

clock = pygame.time.Clock()
running = True

while running:
    screen.fill(BLACK)
    tempo_atual = pygame.time.get_ticks()
    mouse_pos = pygame.mouse.get_pos()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if inicio:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if botao_jogar.clicked(mouse_pos):
                    inicio = False
                    narrativa = True
                elif botao_config.clicked(mouse_pos):
                    inicio = False
                    configuracoes = True
                elif botao_creditos.clicked(mouse_pos):
                    creditos = True
                    inicio = False
                elif botao_sair.clicked(mouse_pos):
                    running = False

        elif narrativa:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RIGHT:
                fala_atual = cenas[indice_cena]["falas"][indice_fala]
                if texto_parcial != fala_atual:
                    texto_parcial = fala_atual
                elif indice_fala < len(cenas[indice_cena]["falas"]) - 1:
                    indice_fala += 1
                    texto_parcial = ""
                    tempo_fala = tempo_atual
                else:
                    if indice_cena < len(cenas) - 1:
                        indice_cena += 1
                        indice_fala = 0
                        texto_parcial = ""
                        tempo_fala = tempo_atual
                    else:
                        pygame.mixer.music.stop()
                        pygame.quit()
                        iniciar_jogo(volume)
                        sys.exit()

        elif creditos:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                creditos = False
                inicio = True
                
        elif configuracoes:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    configuracoes = False
                    inicio = True
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao_volume_mais.clicked(mouse_pos):
                    volume = min(1.0, volume + 0.1)
                    pygame.mixer.music.set_volume(volume)
                elif botao_volume_menos.clicked(mouse_pos):
                    volume = max(0.0, volume - 0.1)
                    pygame.mixer.music.set_volume(volume)

    # Desenho
    if inicio:
        screen.blit(imagens[0], (0, 0))
        for btn in [botao_jogar, botao_config, botao_creditos, botao_sair]:
            btn.update(mouse_pos)
            btn.draw(screen)

    elif narrativa:
        cena = cenas[indice_cena]
        screen.blit(cena["imagem"], (0, 0))
        pygame.draw.rect(screen, DARK_BOX, (40, 20, screen_width - 80, 45), border_radius=8)
        contexto = context_font.render(cena["contexto"], True, WHITE)
        screen.blit(contexto, (55, 30))

        pygame.draw.rect(screen, DARK_BOX, (40, screen_height - 90, screen_width - 80, 70), border_radius=10)
        fala_atual = cenas[indice_cena]["falas"][indice_fala]
        if len(texto_parcial) < len(fala_atual):
            if tempo_atual - tempo_fala > velocidade_texto:
                texto_parcial += fala_atual[len(texto_parcial)]
                tempo_fala = tempo_atual
        fala_renderizada = font.render(texto_parcial, True, WHITE)
        screen.blit(fala_renderizada, (60, screen_height - 85))

    elif creditos:
        screen.fill(BLACK)
        titulo = title_font.render("Créditos", True, GOLD)
        screen.blit(titulo, (screen_width // 2 - titulo.get_width() // 2, 50))
        
        # Texto de descrição do jogo
        descricao = [
            "All In é um jogo digital desenvolvido com Pygame que mistura narrativa e ação,",
            "inspirado em uma história envolvente sobre escolhas, ambição e consequências.",
            "O jogador assume o papel de Gabriel, um jovem da periferia que, em busca de",
            "uma vida melhor para sua família, se envolve com apostas de cassino e precisa",
            "lidar com as consequências de suas decisões. O objetivo principal é sobreviver",
            "à perseguição de um agiota, desviando de obstáculos enquanto o personagem",
            "avança por diferentes fases.",
            "O jogo conta com gráficos em estilo pixel art, que representam cenários urbanos",
            "como o quarto de Gabriel, ruas da periferia e o interior do cassino."
        ]
        
        for i, linha in enumerate(descricao):
            texto = small_font.render(linha, True, WHITE)
            screen.blit(texto, (screen_width // 2 - texto.get_width() // 2, 150 + i * 30))
        
        # Nomes dos desenvolvedores
        dev_titulo = font.render("Desenvolvedores:", True, GOLD)
        screen.blit(dev_titulo, (screen_width // 2 - dev_titulo.get_width() // 2, 450))
        
        nomes = ["Lucas Souza", "Lucas Lacerda", "Wendel Da Costa", "Ali Ahmad", "Leonardo Tonon"]
        for i, nome in enumerate(nomes):
            texto = small_font.render(nome, True, WHITE)
            screen.blit(texto, (screen_width // 2 - texto.get_width() // 2, 500 + i * 30))

        msg = small_font.render("Pressione ESC para voltar", True, GOLD)
        screen.blit(msg, (screen_width // 2 - msg.get_width() // 2, screen_height - 60))
        
    elif configuracoes:
        screen.fill(BLACK)
        titulo = title_font.render("Configurações", True, GOLD)
        screen.blit(titulo, (screen_width // 2 - titulo.get_width() // 2, 100))
        
        # Controle de volume
        volume_texto = font.render(f"Volume: {int(volume * 100)}%", True, WHITE)
        screen.blit(volume_texto, (screen_width // 2 - volume_texto.get_width() // 2, 300))
        
        # Botões de volume (mantidos)
        botao_volume_menos.update(mouse_pos)
        botao_volume_menos.draw(screen)
        botao_volume_mais.update(mouse_pos)
        botao_volume_mais.draw(screen)
        
        msg = small_font.render("Pressione ESC para fechar o jogo", True, GOLD)
        screen.blit(msg, (screen_width // 2 - msg.get_width() // 2, screen_height - 60))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
iniciar_jogo(volume)
sys.exit()