
import pygame
import os
import random

def carregar(nome):
    return pygame.image.load(os.path.join("imagens", nome)).convert_alpha()

def layout1():
    obs = []
    for y in range(100, 600, 140):
        for x in range(80, 880, 220):
            if not (y == 340 and x in [480, 700]):
                obs.append(pygame.Rect(x, y, 100, 20))
    for x in range(160, 800, 250):
        for y in range(140, 600, 180):
            if not (x == 580 and y == 300):
                obs.append(pygame.Rect(x, y, 20, 100))
    return obs

def layout2():
    obs = []
    for x in range(60, 880, 180):
        obs.append(pygame.Rect(x, 200, 100, 20))
        obs.append(pygame.Rect(x, 500, 100, 20))
    for y in range(100, 620, 150):
        obs.append(pygame.Rect(300, y, 20, 100))
        obs.append(pygame.Rect(600, y, 20, 100))
    return obs

def layout3():
    obs = []
    for x in range(100, 800, 230):
        for y in range(100, 600, 170):
            if not (x == 530 and y == 250):
                obs.append(pygame.Rect(x, y, 100, 20))
    for y in range(180, 600, 180):
        if y != 340:
            obs.append(pygame.Rect(400, y, 20, 100))
    return obs

def layout4():
    obs = []
    for x in range(100, 860, 200):
        obs.append(pygame.Rect(x, 150, 100, 20))
        obs.append(pygame.Rect(x, 350, 100, 20))
        obs.append(pygame.Rect(x, 550, 100, 20))
    for y in range(200, 500, 120):
        if y != 300:
            obs.append(pygame.Rect(250, y, 20, 100))
        if y != 400:
            obs.append(pygame.Rect(700, y, 20, 100))
    return obs

def mover_agiota(agiota_rect, alvo_rect, obstaculos, velocidade):
    direcao = pygame.Vector2(alvo_rect.center) - pygame.Vector2(agiota_rect.center)
    if direcao.length() == 0:
        return agiota_rect
    direcao = direcao.normalize()
    dx, dy = direcao.x * velocidade, direcao.y * velocidade
    tentativa = agiota_rect.move(dx, dy)
    if not any(tentativa.colliderect(obs) for obs in obstaculos):
        return tentativa
    tentativa_x = agiota_rect.move(dx, 0)
    if not any(tentativa_x.colliderect(obs) for obs in obstaculos):
        return tentativa_x
    tentativa_y = agiota_rect.move(0, dy)
    if not any(tentativa_y.colliderect(obs) for obs in obstaculos):
        return tentativa_y
    return agiota_rect

def atualizar_ranking(ranking_path, nome, pontos):
    ranking = {}
    if os.path.exists(ranking_path):
        with open(ranking_path, "r") as f:
            for linha in f:
                if ":" in linha:
                    partes = linha.strip().split(":")
                    if len(partes) == 2 and partes[1].isdigit() and len(partes[0]) == 3:
                        nome_ = partes[0]
                        pontos_ = int(partes[1])
                        if nome_ not in ranking or pontos_ > ranking[nome_]:
                            ranking[nome_] = pontos_
    ranking[nome] = max(ranking.get(nome, 0), pontos)
    return sorted(ranking.items(), key=lambda x: x[1], reverse=True)[:5]

def iniciar_jogo():
    pygame.init()
    pygame.mixer.init()
    pygame.mixer.music.load("imagens/musica_cassino.wav")
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play(-1)

    WIDTH, HEIGHT = 960, 720
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("All In")

    PRETO = (0, 0, 0)
    AZUL = (0, 0, 255)
    BRANCO = (255, 255, 255)
    AMARELO = (255, 255, 0)
    VERMELHO = (255, 0, 0)

    fonte = pygame.font.SysFont("arial", 28)
    clock = pygame.time.Clock()

    gabriel_img = pygame.transform.scale(carregar("gabriel.png"), (60, 60))
    caca_niquel_img = pygame.transform.scale(carregar("caca_niquel.png"), (75, 75))
    nota_img = pygame.transform.scale(carregar("nota_dinheiro.png"), (30, 30))
    saco_img = pygame.transform.scale(carregar("moeda_saco.png"), (30, 30))
    agiota_img = pygame.transform.scale(carregar("agiota.png"), (60, 60))

    fase = 1
    dinheiro = 200
    pontuacao_total = 0
    layouts = [layout1, layout2, layout3, layout4]

    while True:
        obstaculos = random.choice(layouts)()
        gabriel_rect = gabriel_img.get_rect(topleft=(40, 40))
        caca_niquel_rect = caca_niquel_img.get_rect(bottomright=(WIDTH - 40, HEIGHT - 40))
        coletaveis = []
        agiota_rect = agiota_img.get_rect(topleft=(WIDTH - 100, 40))
        agiota_vel = fase + 1
        movimento_iniciado = False

        if fase >= 2:
            dinheiro = 0
            total_disponivel = 0
            while total_disponivel < 200:
                x, y = random.randint(40, WIDTH - 70), random.randint(40, HEIGHT - 70)
                item_rect = pygame.Rect(x, y, 30, 30)
                if not any(item_rect.colliderect(o) for o in obstaculos) and not item_rect.colliderect(gabriel_rect):
                    tipo = random.choice(["nota", "saco"])
                    valor = 50 if tipo == "nota" else 20
                    img = nota_img if tipo == "nota" else saco_img
                    rect = img.get_rect(topleft=(x, y))
                    coletaveis.append({"valor": valor, "rect": rect, "img": img})
                    total_disponivel += valor

        rodando = True
        mostrar_mensagem = ""

        while rodando:
            screen.fill(PRETO)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return

            teclas = pygame.key.get_pressed()
            movimento = [0, 0]
            if teclas[pygame.K_LEFT]: movimento[0] -= 4
            if teclas[pygame.K_RIGHT]: movimento[0] += 4
            if teclas[pygame.K_UP]: movimento[1] -= 4
            if teclas[pygame.K_DOWN]: movimento[1] += 4
            if any(movimento): movimento_iniciado = True

            novo_rect = gabriel_rect.move(movimento)
            if (0 <= novo_rect.left <= WIDTH - gabriel_img.get_width() and
                0 <= novo_rect.top <= HEIGHT - gabriel_img.get_height() and
                not any(novo_rect.colliderect(obs) for obs in obstaculos)):
                gabriel_rect = novo_rect

            for item in coletaveis[:]:
                if gabriel_rect.colliderect(item["rect"]):
                    dinheiro += item["valor"]
                    pontuacao_total += item["valor"]
                    coletaveis.remove(item)

            if fase >= 2 and movimento_iniciado:
                agiota_rect = mover_agiota(agiota_rect, gabriel_rect, obstaculos, agiota_vel)

            if fase >= 2 and gabriel_rect.colliderect(agiota_rect):
                pygame.mixer.music.stop()
                nome = ""
                cursor_timer = 0
                cursor_visible = True
                ranking_path = "ranking.txt"

                while True:
                    screen.fill(PRETO)
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                            return
                        if event.type == pygame.KEYDOWN:
                            if len(nome) < 3 and event.unicode.isalpha():
                                nome += event.unicode.upper()
                            if event.key == pygame.K_BACKSPACE:
                                nome = nome[:-1]
                            if len(nome) == 3:
                                ranking = atualizar_ranking(ranking_path, nome, pontuacao_total)
                                with open(ranking_path, "w") as f:
                                    for n, p in ranking:
                                        f.write(f"{n}:{p}\n")
                                break

                    game_over_text = fonte.render("GAME OVER", True, VERMELHO)
                    instrucao = fonte.render("Digite 3 letras para salvar sua pontuação:", True, VERMELHO)
                    cursor_timer += 1
                    if cursor_timer > 30:
                        cursor_visible = not cursor_visible
                        cursor_timer = 0
                    cursor = "_" * (3 - len(nome)) if cursor_visible else " " * (3 - len(nome))
                    entrada = fonte.render(nome + cursor, True, BRANCO)

                    screen.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 3))
                    screen.blit(instrucao, (WIDTH // 2 - instrucao.get_width() // 2, HEIGHT // 3 + 50))
                    screen.blit(entrada, (WIDTH // 2 - entrada.get_width() // 2, HEIGHT // 3 + 100))
                    pygame.display.flip()
                    clock.tick(60)

                screen.fill(PRETO)
                titulo = fonte.render("RANKING - MELHORES JOGADORES", True, AMARELO)
                screen.blit(titulo, (WIDTH // 2 - titulo.get_width() // 2, 100))
                for i, (nome_r, pts) in enumerate(ranking):
                    linha = fonte.render(f"{i + 1}. {nome_r} - {pts} pts", True, BRANCO)
                    screen.blit(linha, (WIDTH // 2 - linha.get_width() // 2, 160 + i * 40))
                reinicio = fonte.render("Aperte ESPAÇO para tentar novamente", True, AMARELO)
                screen.blit(reinicio, (WIDTH // 2 - reinicio.get_width() // 2, HEIGHT - 100))
                pygame.display.flip()

                esperando = True
                while esperando:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                            return
                        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                            iniciar_jogo()
                            return

            for rect in obstaculos:
                pygame.draw.rect(screen, AZUL, rect)
            for item in coletaveis:
                screen.blit(item["img"], item["rect"])
            screen.blit(gabriel_img, gabriel_rect)
            screen.blit(caca_niquel_img, caca_niquel_rect)
            if fase >= 2:
                screen.blit(agiota_img, agiota_rect)

            screen.blit(fonte.render(f"Dinheiro: R$ {dinheiro}", True, AMARELO), (20, 20))
            screen.blit(fonte.render(f"Pontuação: {pontuacao_total}", True, AMARELO), (WIDTH - 260, 20))

            if gabriel_rect.colliderect(caca_niquel_rect):
                if fase == 1 or dinheiro >= 200:
                    texto = fonte.render("Você perdeu. Indo para a próxima fase...", True, BRANCO)
                    screen.blit(texto, (WIDTH // 2 - texto.get_width() // 2, HEIGHT - 60))
                    pygame.display.flip()
                    pygame.time.delay(3000)
                    fase += 1
                    break
                else:
                    mostrar_mensagem = "Você não tem dinheiro suficiente!"

            if not gabriel_rect.colliderect(caca_niquel_rect):
                mostrar_mensagem = ""

            if mostrar_mensagem:
                texto = fonte.render(mostrar_mensagem, True, BRANCO)
                screen.blit(texto, (WIDTH // 2 - texto.get_width() // 2, HEIGHT - 60))

            pygame.display.flip()
            clock.tick(60)

if __name__ == "__main__":
    iniciar_jogo()
